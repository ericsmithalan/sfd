import math

METERS_TO_INCHES = 39.3700787402

def truncate(n, decimals=0):
    multiplier = 10**decimals
    return int(n * multiplier) / multiplier


def gcd(a, b):
    if b == 0:
        return a
    else:
        return gcd(b, a % b)


def mkinch(value, lowest_denominator=32):
    value = round(value, 3)

    if value.is_integer():
        return "%s" % (int(value))
    else:
        number = math.ceil((value-int(value))*1000/lowest_denominator)

        thegcd = gcd(number, lowest_denominator)

        numerator = int(number/thegcd)
        denominator = int(lowest_denominator/thegcd)

    if denominator > 1 and value > 0:
        return "%s %s/%s" % (int(value), numerator, denominator)
    elif value == 0:
        return "%s/%s" % (int(value), numerator, denominator)
    else:
        return "%s" % (int(value))
