
bl_info = {
    "name": "QOL HUD Distance",
    "author": "Rico Holmes",
    "version": (2, 0, 1),
    "blender": (3, 6, 0),
    "category": "QOL Tools",
    }

import bpy,blf,bmesh,os,bpy_extras,gpu
import bpy_extras.view3d_utils
from mathutils import Vector
from bpy.types import Panel
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent
from bpy.types import AddonPreferences
from bpy.props import (BoolProperty,IntProperty,EnumProperty,StringProperty,FloatProperty,FloatVectorProperty)
from .utils import mkinch
denominators = [
    ("4", "4th", "", 4),
    ("8", "8th", "", 8),
    ("16", "16th", "", 16),
    ("32", "32nd", "", 32),
    ("64", "64th", "", 64),
]

#--------------------------------------------------------------

class QOLHUD_Distance_NPanel(Panel):
    bl_idname = "QOL_PT_Distance_NPanel"
    bl_label = "QOL HUD Distance"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "QOL HUD"

    def draw(self, context):
        prefs = bpy.context.preferences.addons[__package__].preferences
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.operator("view3d.qol_selection_lock", text="Lock Selection", icon="LOCKED" if cPersistant.locked else "UNLOCKED")
        layout.prop(prefs, "On", text="On or Off")
        layout.prop(prefs, "Nearest", text="Nearest")
        layout.prop(prefs, "helperLine", text="Helper Line")
        layout.prop(prefs, "helperLineColor", text="Line Color")
        if prefs.helperLine:
            layout.prop(prefs, "helperLineExtended", text="Extended Helper XYZ")
            layout.prop(prefs, "LabelFontSize", text="Line Font Size")
        if prefs.helperLineExtended and prefs.helperLine:
            layout.prop(prefs, "helperXColor", text="X Color")
            layout.prop(prefs, "helperYColor", text="Y Color")
            layout.prop(prefs, "helperZColor", text="Z Color")
        layout.prop(prefs, "DistanceText", text="Distance Text")
        layout.prop(prefs, "TextSize", text="Text Size")
        layout.prop(prefs, "TextOffsetX", text="Text Horizontal Offset")
        layout.prop(prefs, "TextOffsetY", text="Text Vertical Offset")
        layout.prop(prefs, "LabelTextColor", text="Label Text Color")
        layout.prop(prefs, "DigitsColor", text="Digits Text Color")
        layout.prop(prefs, "shadowTransparency", text="Shadow")
        layout.prop(prefs, "shadowOffset", text="Shadow Size")
        layout.prop(prefs, "BackgroundBox", text="Background")
        layout.prop(prefs, "BackgroundBoxColor", text="Background Color")
#--------------------------------------------------------------
def get_object_distance():
    startVec = 0
    endVec = 0
    dist = 0
    if cPersistant.locked:
        if cPersistant.dataType in {"(Vertices)", "(Edges)", "(Faces)"}:
            if cPersistant.dataType == "(Vertices)":
                startVec = bpy.data.objects[cPersistant.object_pointer_a].data.vertices[cPersistant.component_index_a].co
                endVec = bpy.data.objects[cPersistant.object_pointer_b].data.vertices[cPersistant.component_index_b].co
            elif cPersistant.dataType == "(Edges)":
                vert1_index, vert2_index = bpy.data.objects[cPersistant.object_pointer_a].data.edges[cPersistant.component_index_a].vertices
                vert1_POS = bpy.data.objects[cPersistant.object_pointer_a].data.vertices[vert1_index].co
                vert2_POS = bpy.data.objects[cPersistant.object_pointer_a].data.vertices[vert2_index].co
                startVec = (vert1_POS + vert2_POS) *0.5
                vert1_index, vert2_index = bpy.data.objects[cPersistant.object_pointer_b].data.edges[cPersistant.component_index_b].vertices
                vert1_POS = bpy.data.objects[cPersistant.object_pointer_b].data.vertices[vert1_index].co
                vert2_POS = bpy.data.objects[cPersistant.object_pointer_b].data.vertices[vert2_index].co
                endVec = (vert1_POS + vert2_POS) *0.5
            elif cPersistant.dataType == "(Faces)":
                startVec = bpy.data.objects[cPersistant.object_pointer_a].data.polygons[cPersistant.component_index_a].center
                endVec = bpy.data.objects[cPersistant.object_pointer_b].data.polygons[cPersistant.component_index_b].center
            startVec = bpy.data.objects[cPersistant.object_pointer_a].matrix_world @ startVec
            endVec = bpy.data.objects[cPersistant.object_pointer_b].matrix_world @ endVec
            dist,distX,distY,distZ = getAxisDistance(startVec,endVec)
            return (startVec,endVec,dist,
                    convert_distance_to_string(dist),
                    convert_distance_to_string(distX),
                    convert_distance_to_string(distY),
                    convert_distance_to_string(distZ),cPersistant.dataType)
        else:
            cPersistant.dataType = "(Objects)"
            obj_A = bpy.data.objects.get(cPersistant.object_pointer_a)
            obj_B = bpy.data.objects.get(cPersistant.object_pointer_b)
            if obj_A == None or obj_B == None:
                cPersistant.object_pointer_a = ""
                cPersistant.object_pointer_b = ""
                cPersistant.locked = False
                return startVec,endVec,dist,"","","","","(Objects)"
            else:
                startVec = obj_A.matrix_world @ Vector((0, 0, 0))
                endVec = obj_B.matrix_world @ Vector((0, 0, 0))
                dist,distX,distY,distZ = getAxisDistance(startVec,endVec)
                return (startVec,endVec,dist,
                        convert_distance_to_string(dist),
                        convert_distance_to_string(distX),
                        convert_distance_to_string(distY),
                        convert_distance_to_string(distZ),
                        "(Objects)")
    else:
        objs = bpy.context.selected_objects

        if len(objs) == 2:
            cPersistant.dataType = "(Objects)"
            startVec = objs[0].matrix_world @ Vector((0, 0, 0))
            cPersistant.object_pointer_a = objs[0].name
            endVec = objs[1].matrix_world @ Vector((0, 0, 0))
            cPersistant.object_pointer_b = objs[1].name
            dist,distX,distY,distZ = getAxisDistance(startVec,endVec)

            return (startVec,endVec,dist,
                    convert_distance_to_string(dist),
                    convert_distance_to_string(distX),
                    convert_distance_to_string(distY),
                    convert_distance_to_string(distZ),"(Objects)")

        else:
            return startVec,endVec,dist,"","","","","(Transition)"

                    


#--------------------------------------------------------------
def getDistance():
    try:
        if bpy.context.mode == 'OBJECT':
            (startVec, endVec, dist,distanceAsString,distStringX,
            distStringY,distStringZ,objectDistanceType) = get_object_distance()
            return startVec, endVec, dist,distanceAsString,distStringX,distStringY,distStringZ,objectDistanceType
        elif bpy.context.mode == 'EDIT_MESH':
            if bpy.context.object.type != 'MESH':
                return 0,0,0,"",""
            (startVec, endVec, dist, distanceAsString, distStringX,
            distStringY, distStringZ, objectDistanceType) = get_component_distance()
            return startVec, endVec, dist, distanceAsString, distStringX, distStringY, distStringZ, objectDistanceType
    #print exception and error message
    except Exception as e:
        print(e)
        return 0,0,0,"","","","","(Transition)"

# --------------------------------------------------------------
class QOL_OT_SelectionLock(bpy.types.Operator):
    bl_idname = "view3d.qol_selection_lock"
    bl_label = "Selection Lock"
    bl_description = "Locks selection to the current selection mode"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cPersistant.locked = not cPersistant.locked
        cPersistant.dataType = check_selection_mode()
        if cPersistant.locked:
            if cPersistant.dataType == "(Objects)": # If we have objects selected, lock them
                if len(context.selected_objects)>1: # If we have more than one object selected, lock the first two
                    cPersistant.object_pointer_a = context.active_object.name
                    cPersistant.object_pointer_b = context.selected_objects[1].name if context.active_object.name != context.selected_objects[1].name else context.selected_objects[0].name
        else:
            if cPersistant.dataType == "(Objects)":
                cPersistant.object_pointer_a = ""
                cPersistant.object_pointer_b = ""

        context.area.tag_redraw()
        return {'FINISHED'}
#--------------------------------------------------------------
class QOLHUD_Distance_DrawingClass:
    _handle = None
    _handle_3d = None

    @staticmethod
    def draw_callback_px():
        prefs = bpy.context.preferences.addons[__package__].preferences
        if prefs.On:
            try:
                startVec,endVec,dist,distanceAsString,distStringX,distStringY,distStringZ,distanceType = getDistance()
            except:
                return
            if distanceType == "(Transition)":
                return
            if dist != 0:
                text_distance = prefs.DistanceText
                text_distanceType = distanceType
                if cPersistant.object_pointer_a != cPersistant.object_pointer_b:
                    distanceType = (distanceType.replace(")", "") + " multi object)")
                    text_distanceType = distanceType
                if cPersistant.locked:
                    text_distance = ("🔒" + prefs.DistanceText)
                    text_distanceType = ("      " + distanceType) # Add some spaces to align the text

                font_id = 0  # Default font.
                blf.size(font_id, (20 * prefs.TextSize))  # 20 * 0.7 = 14
                dist_type_text_dims = blf.dimensions(font_id, distanceType)
                # Text color settings.
                color_distance = prefs.LabelTextColor
                color_distanceType = prefs.color_distanceType
                DigitsColor = prefs.DigitsColor
                proxyTexts = [(text_distance, color_distance), ("888.88X", DigitsColor)]
                texts = [(text_distance, color_distance), (distanceAsString, DigitsColor)]
                text_dims = prefs.DistanceText
                # Calculate the size of the text.
                total_width = sum(blf.dimensions(font_id, t[0])[0] for t in proxyTexts)
                textHeight = blf.dimensions(font_id, text_dims)[1]
                # Set the background color and transparency
                blf.enable(font_id, blf.SHADOW)
                blf.shadow(font_id, 5, 0, 0, 0, prefs.shadowTransparency)  # 50% transparent black
                blf.shadow_offset(font_id, prefs.shadowOffset,(prefs.shadowOffset * -1))
                # Draw the text.
                pos_y = prefs.TextOffsetY
                pos_x = bpy.context.area.width - total_width - prefs.TextOffsetX
                init_pos_x = pos_x
                # Calculate the width and height of the rectangle.
                boxPadding = 10
                rect_width = total_width + (boxPadding * 2) # Add some padding
                rect_height = textHeight + dist_type_text_dims[1]*1.2 + (blf.dimensions(font_id, text_dims)[1] *0.75)
                # Calculate the position of the rectangle.
                rect_pos_x = bpy.context.area.width - rect_width + boxPadding - prefs.TextOffsetX
                rect_pos_y = prefs.TextOffsetY
                # Draw the dark BackgroundBox rectangle.
                if prefs.BackgroundBox:
                    draw_2d_rectangle(rect_pos_x, rect_pos_y, rect_width, rect_height)

                for txt, color in texts:
                    blf.color(font_id, *color)
                    blf.position(font_id, pos_x, pos_y, 0)
                    blf.draw(font_id, txt)
                    pos_x += blf.dimensions(font_id, txt)[0]  # Update pos_x

                # Drawing the distance type under the distance text.
                blf.size(font_id, (20 * prefs.TextSize)*prefs.DistanceTypeSize)
                blf.color(font_id, *color_distanceType) # Use the color of distance for simplicity. Change if necessary.
                pos_y = round(pos_y - (rect_height * 0.35))
                blf.position(font_id, init_pos_x, pos_y, 0)
                blf.draw(font_id, text_distanceType)

                # Draw midPoint Measurement on direct line
                if prefs.helperLine:
                    midpoint_direct_2d = getScreenMidpoint(startVec,endVec,"ALL")
                    if midpoint_direct_2d:  # Check if the midpoint is visible in the viewport
                        font_id = 0  # Default font
                        textWidthCenter = blf.dimensions(font_id, (distanceAsString))[0] * 0.5
                        blf.position(font_id, (midpoint_direct_2d.x -textWidthCenter), midpoint_direct_2d.y, 0)
                        blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
                        blf.size(font_id, 20 * prefs.LabelFontSize)  # Set font size and DPI (DPI deprecated and removed for 4.0)
                        blf.draw(font_id, distanceAsString)

                if prefs.helperLineExtended and prefs.helperLine:
                    end_of_x = (endVec[0], startVec[1], startVec[2])
                    end_of_y = (end_of_x[0], endVec[1], end_of_x[2])
                    if distanceAsString != distStringX:
                        midpoint_x_2d = getScreenMidpoint (startVec,endVec,"X")
                        if midpoint_x_2d:  # Check if the midpoint is visible in the viewport
                            font_id = 0  # Default font
                            textWidthCenter = blf.dimensions(font_id, distStringX)[0] * 0.5
                            col = prefs.helperXColor
                            blf.position(font_id, (midpoint_x_2d.x -textWidthCenter), midpoint_x_2d.y, 0)
                            blf.color(font_id, col[0], col[1], col[2], col[3])
                            blf.size(font_id, 20 * prefs.LabelFontSize)  # Set font size and DPI
                            blf.draw(font_id, distStringX)

                    if distanceAsString != distStringY:
                        # end_of_x = (endVec[0], startVec[1], startVec[2])
                        vertices_y = [end_of_x, (end_of_x[0], endVec[1], end_of_x[2])]
                        midpoint_y_2d = getScreenMidpoint (vertices_y[0],vertices_y[1],"Y")
                        if midpoint_y_2d:  # Check if the midpoint is visible in the viewport
                            font_id = 0  # Default font
                            textWidthCenter = blf.dimensions(font_id, distStringY)[0] * 0.5
                            col = prefs.helperYColor
                            blf.position(font_id, (midpoint_y_2d.x -textWidthCenter), midpoint_y_2d.y, 0)
                            blf.color(font_id, col[0], col[1], col[2], col[3])
                            blf.size(font_id, 20 * prefs.LabelFontSize)  # Set font size and DPI
                            blf.draw(font_id, distStringY)
                    if distanceAsString != distStringZ:
                        # end_of_y = (end_of_x[0], endVec[1], end_of_x[2])
                        vertices_z = [end_of_y, (end_of_y[0], end_of_y[1], endVec[2])]
                        midpoint_z_2d = getScreenMidpoint (vertices_z[0],vertices_z[1],"Z")
                        if midpoint_z_2d:  # Check if the midpoint is visible in the viewport
                            font_id = 0  # Default font
                            textWidthCenter = blf.dimensions(font_id, distStringZ)[0] * 0.5
                            col = prefs.helperZColor
                            blf.position(font_id, (midpoint_z_2d.x -textWidthCenter), midpoint_z_2d.y, 0)
                            blf.color(font_id, col[0], col[1], col[2], col[3])
                            blf.size(font_id, 20 * prefs.LabelFontSize)  # Set font size and DPI
                            blf.draw(font_id, distStringZ)



                blf.disable(font_id, blf.SHADOW)

    @staticmethod
    def draw_callback_3d():
        prefs = bpy.context.preferences.addons[__package__].preferences
        if prefs.On:
            if prefs.helperLine:
                try:
                    startVec, endVec, dist, distanceAsString,distStringX,distStringY,distStringZ, distanceType = getDistance()
                except:
                    return
                if distanceType == "(Transition)":
                    return                
                
                if prefs.helperLineExtended and prefs.helperLine:
                    try:
                        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                        shader.bind()
                        gpu.state.blend_set("ALPHA")
                        shader.uniform_float("color", prefs.helperXColor)  # Red
                        vertices_x = [startVec, (endVec[0], startVec[1], startVec[2])]
                        batch_x = batch_for_shader(shader, 'LINES', {"pos": vertices_x}, indices=[(0, 1)])
                        batch_x.draw(shader)
                        end_of_x = vertices_x[1]
                        shader.uniform_float("color", prefs.helperYColor) # Green
                        vertices_y = [end_of_x, (end_of_x[0], endVec[1], end_of_x[2])]
                        batch_y = batch_for_shader(shader, 'LINES', {"pos": vertices_y}, indices=[(0, 1)])
                        batch_y.draw(shader)
                        end_of_y = vertices_y[1]
                        shader.uniform_float("color", prefs.helperZColor) # Blue
                        vertices_z = [end_of_y, (end_of_y[0], end_of_y[1], endVec[2])]
                        batch_z = batch_for_shader(shader, 'LINES', {"pos": vertices_z}, indices=[(0, 1)])
                        batch_z.draw(shader)
                    except:
                        pass
                if prefs.helperLine:
                    try:
                        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                        shader.bind()
                        gpu.state.blend_set("ALPHA")
                        shader.uniform_float("color", prefs.helperLineColor)
                        vertices = [startVec, endVec]
                        batch = batch_for_shader(shader, 'LINES', {"pos": vertices}, indices=[(0, 1)])
                        batch.draw(shader)
                    except:
                        pass


                gpu.state.blend_set("NONE")

      
    @classmethod
    def handle_add(cls):
        if cls._handle is None:
            cls._handle = bpy.types.SpaceView3D.draw_handler_add(cls.draw_callback_px, (), 'WINDOW', 'POST_PIXEL')
        if cls._handle_3d is None:
            cls._handle_3d = bpy.types.SpaceView3D.draw_handler_add(cls.draw_callback_3d, (), 'WINDOW', 'POST_VIEW')

    @classmethod
    def handle_remove(cls):
        if cls._handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(cls._handle, 'WINDOW')
            cls._handle = None
        if cls._handle_3d is not None:
            bpy.types.SpaceView3D.draw_handler_remove(cls._handle_3d, 'WINDOW')
            cls._handle_3d = None



# ================================================================================================
# ================================================================================================
# ================================================================================================

#Preferences

class QOLHUD_Distance_Preferences(AddonPreferences):
    bl_idname = __name__
    TextSize: FloatProperty(
        name = "Text size multiplier",
        default = 1,
        min = 0.1,
        max = 10,
        ) #type: ignore
    Nearest: EnumProperty(
        items=denominators,
        name="Nearest",
        description="Nearest nth",
        default=32
        ) #type: ignore
    TextOffsetY: IntProperty(
        name = "Text Vertical Offset",
        default = 45,
        min = 0,
        max = 6000,
        ) #type: ignore
    TextOffsetX: IntProperty(
        name = "Text Horizontal Offset",
        default = 38,
        min = 0,
        max = 6000,
        ) #type: ignore
    DistanceText: StringProperty(
        name = "Distance Label Text",
        default = "Distance: ",
        ) #type: ignore
    DistanceTypeSize: FloatProperty(
        name = "Distance Type Size",
        default = 0.75,
        min = 0.1,
        max = 10,
        ) #type: ignore
    BackgroundBox: BoolProperty(
        name = "Background",
        description = "Whether to show the background box or not",
        default = True,
        ) #type: ignore
    BackgroundBoxColor: FloatVectorProperty(
        name = "Background Box Color",
        subtype = "COLOR_GAMMA",
        size=4,
        default = (0.0, 0.0, 0.0, 0.5),
        min = 0.0,
        max = 1.0,
        ) #type: ignore
    LabelText : StringProperty(
        name = "Label Text",
        default = "Distance: ",
        ) #type: ignore
    LabelTextColor: FloatVectorProperty(
        name = "Label Text Color",
        subtype = "COLOR_GAMMA",
        size=4,
        default = (1.0, 0.569, 0.035, 1.0),
        min = 0.0,
        max = 1.0,
        ) #type: ignore
    LabelFontSize: FloatProperty(
        name = "Label Font Size",
        default = 1.0,
        min = 0.1,
        max = 10,
        ) #type: ignore
    shadow: BoolProperty(
        name = "Shadow",
        description = "Whether to show a shadow behind the text or not",
        default = True,
        ) #type: ignore
    shadowTransparency: FloatProperty(
        name = "Shadow Transparency",
        description = "How transparent the shadow is",
        default = 0.5,
        min = 0.0,
        max = 1.0,
        ) #type: ignore
    helperLine: BoolProperty(
        name = "Helper Line",
        description = "Whether to show a line between the two objects or not",
        default = True,
        ) #type: ignore
    helperLineColor: FloatVectorProperty(
        name = "Helper Line Color",
        subtype = "COLOR_GAMMA",
        size=4,
        default = (.3, 0.6, 0.6, 1.0),
        min = 0.0,
        max = 1.0,
        ) #type: ignore
    helperLineExtended: BoolProperty(
        name = "Helper Line Extended",
        description = "Display X Y Z Axis Distances",
        default = True,
        ) #type: ignore
    helperXColor: FloatVectorProperty(
        name = "Helper X Color",
        subtype = "COLOR_GAMMA",
        size=4,
        default = (1.0, 0.446, 0.542, 1.0),
        min = 0.0,
        max = 1.0,
        ) #type: ignore
    helperYColor: FloatVectorProperty(
        name = "Helper Y Color",
        subtype = "COLOR_GAMMA",
        size=4,
        default = (0.529, 1.0, 0.0, 1.0),
        min = 0.0,
        max = 1.0,
        ) #type: ignore
    helperZColor: FloatVectorProperty(
        name = "Helper Z Color",
        subtype = "COLOR_GAMMA",
        size=4,
        default = (0.0, 0.78, 1.0, 1.0),
        min = 0.0,
        max = 1.0,
        ) #type: ignore

    shadowOffset: IntProperty(
        name = "Shadow Horizontal Offset",
        default = 2,
        min = 0,
        max = 10,
        ) #type: ignore
    color_distanceType: FloatVectorProperty(
        name = "Axis Text Color",
        subtype = "COLOR",
        size=4,
        default = (1.0, 1.0, 1.0, 0.4),
        min = 0.0,
        max = 1.0,
        ) #type: ignore
    DigitsColor: FloatVectorProperty(
        name = "Digits Text Color",
        subtype = "COLOR",
        size=4,
        default = (1.0, 1.0, 1.0, 1.0),
        min = 0.0,
        max = 1.0,
        ) #type: ignore
    On: BoolProperty(
        name = "On or Off",
        description = "Whether to show the HUD or not",
        default = True,
        ) #type: ignore
    
    Npanel: BoolProperty(
        name = "N Panel",
        description = "Whether to show the N panel",
        default = True,
        ) #type: ignore
    
    calcEval: BoolProperty(
        name = "Calculate Evaluated",
        description = "Whether to calculate the polycount of the evaluated mesh or not",
        default = True,
        ) #type: ignore

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        box = row.box()
        row = box.row()
        row.prop(self, "TextSize")
        row.prop(self, "TextOffsetX")
        row.prop(self, "TextOffsetY")
        row = box.row()
        row.prop(self, "DistanceText")
        row = box.row()
        row.prop(self, "DimensionsColor")
        row = box.row()
        row.prop(self, "AxisColor")
        row = box.row()
        row.prop(self, "DigitsColor")
        row = box.row()
        row.prop(self, "Npanel", text="Own QOL HUD NPanel (shown in view tab otherwise)")


class DistancesSingleton:
    _instance = None
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(DistancesSingleton, cls).__new__(cls)
        return cls._instance
    def __init__(self):
        self.locked = False
        self.dataType = None
        self.object_pointer_a = ""
        self.object_pointer_b = ""
        self.component_index_a = None
        self.component_index_b = None
cPersistant = DistancesSingleton()


# ================================================================================================
# ================================================================================================
# ================================================================================================

# Functions

import bpy.utils.previews
global distIcons_dict
# distIcons_dict = bpy.utils.previews.new()
# icons_dir = os.path.join(os.path.dirname(__file__), "icons")
# distIcons_dict.load("distanceAxis", os.path.join(icons_dir, "distanceAxis.png"), 'IMAGE')
# distIcons_dict.load("distanceLine", os.path.join(icons_dir, "distanceLine.png"), 'IMAGE')
# distIcons_dict.load("distanceMeasure", os.path.join(icons_dir, "distanceMeasure.png"), 'IMAGE')
#--------------------------------------------------------------
def topbarIcon(self, context):
    prefs = bpy.context.preferences.addons[__package__].preferences
    icon_value = distIcons_dict["distanceMeasure"].icon_id
    if prefs.helperLine:
        icon_value = distIcons_dict["distanceLine"].icon_id
    if prefs.helperLineExtended:
        icon_value = distIcons_dict["distanceAxis"].icon_id
    self.layout.operator("view3d.qol_axis_toggler", text="", icon_value=icon_value)
#--------------------------------------------------------------
class QOL_OT_Distance_AxisToggler(bpy.types.Operator):
    bl_idname = "view3d.qol_axis_toggler"
    bl_label = "Axis Toggler"
    bl_description = "Toggles the visibility of the QOL HUD dimensions axis"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__package__].preferences
        if prefs.helperLine and not prefs.helperLineExtended:
            prefs.helperLine = True
            prefs.helperLineExtended = True
        elif prefs.helperLineExtended:
            prefs.helperLine = False
            prefs.helperLineExtended = False
        else:
            prefs.helperLine = True
            prefs.helperLineExtended = False
        context.area.tag_redraw()
        return {'FINISHED'}
#--------------------------------------------------------------
def draw_2d_rectangle(pos_x, pos_y, width, height):
    prefs = bpy.context.preferences.addons[__package__].preferences
    BackgroundBoxColor = prefs.BackgroundBoxColor
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')

    bottom_left = (pos_x, pos_y - (height * 0.5))
    bottom_right = (pos_x + width, pos_y - (height * 0.5))
    top_right = (pos_x + width, pos_y + (height * 0.5))
    top_left = (pos_x, pos_y + (height * 0.5))

    batch = batch_for_shader(shader, 'TRI_FAN', {"pos": [bottom_left, bottom_right, top_right, top_left]})
    shader.bind()
    shader.uniform_float("color", BackgroundBoxColor)
    gpu.state.blend_set("ALPHA")
    batch.draw(shader)
    gpu.state.blend_set("NONE")
#--------------------------------------------------------------
def check_selection_mode():
    if bpy.context.mode != 'EDIT_MESH':
        return '(Objects)'
    if bpy.context.object.type != 'MESH':
        return '(Objects)'    
    select_mode = bpy.context.tool_settings.mesh_select_mode
    if select_mode[0]: return '(Vertices)'
    elif select_mode[1]: return '(Edges)'
    elif select_mode[2]: return '(Faces)'
    else: return 'UNKNOWN'
# --------------------------------------------------------------
def getScreenMidpoint(startVec,endVec,axis):
    #axis is a text string
    # print("finding C Persistent .. ",cPersistant.locked)
    region = bpy.context.region
    rv3d = bpy.context.region_data
    if axis == "X":
        midpoint_x = (startVec[0] + endVec[0]) / 2.0
        midpoint_2d = bpy_extras.view3d_utils.location_3d_to_region_2d(region, rv3d, Vector((midpoint_x, startVec[1], startVec[2])))
    if axis == "Y":
        midpoint_y = (startVec[1] + endVec[1]) / 2.0
        midpoint_2d = bpy_extras.view3d_utils.location_3d_to_region_2d(region, rv3d, Vector((startVec[0], midpoint_y, startVec[2])))
    if axis == "Z":
        midpoint_z = (startVec[2] + endVec[2]) / 2.0
        midpoint_2d = bpy_extras.view3d_utils.location_3d_to_region_2d(region, rv3d, Vector((startVec[0], startVec[1], midpoint_z)))
    if axis == "ALL":
        midpoint_x = (startVec[0] + endVec[0]) / 2.0
        midpoint_y = (startVec[1] + endVec[1]) / 2.0
        midpoint_z = (startVec[2] + endVec[2]) / 2.0
        midpoint_2d = bpy_extras.view3d_utils.location_3d_to_region_2d(region, rv3d, Vector((midpoint_x, midpoint_y, midpoint_z)))

    if midpoint_2d:  # Check if the midpoint is visible in the viewport
        return midpoint_2d
    else:
        return False



# ================================================================================================
# ================================================================================================
# ================================================================================================

# Measure

#--------------------------------------------------------------
def remove_trailing_zeroes(value, precision=1):
	format_string = f"{{:.{precision}f}}"  
	str_value = format_string.format(value) 
	return str_value.rstrip('0').rstrip('.')  

#--------------------------------------------------------------
def convert_distance_to_string(distance):
    prefs = bpy.context.preferences.addons[__package__].preferences
    unit_settings = bpy.context.scene.unit_settings
    unit_system = unit_settings.system
    unit_scale = unit_settings.scale_length
    distance *= unit_scale
    if unit_system == 'METRIC':
        if distance < 0.00001:
            return ""
        if distance < 0.0001:
            μm = distance * 1000000  # convert to micrometers
            return "{}μm".format(remove_trailing_zeroes(μm,0))
        elif distance < 0.01:
            mm = distance * 1000  # convert to millimeters
            return "{}mm".format(remove_trailing_zeroes(mm,1))
        elif distance < 1.0:
            cm = distance * 100  # convert to centimeters
            return "{}cm".format(remove_trailing_zeroes(cm,1))
        elif distance < 1000.0:
            m = distance  # convert to meters
            return "{}m".format(remove_trailing_zeroes(m,2))
        else:
            km = distance / 1000
            return "{}km".format(remove_trailing_zeroes(km,2))
    elif unit_system == 'IMPERIAL':
        # feet, inches = divmod(distance * 3.281, 1)  # Convert from meters to feet
        # inches *= 12  # convert decimal part to inches
        # return "{:.0f}' {:.0f}\"".format(feet, inches)
        inches = distance * 39.3700787402
        fraction = mkinch(inches, int(prefs.Nearest))
        return "{0:.3f} ({1})".format(inches, fraction)
    else:
         return str(distance) 
#--------------------------------------------------------------
def getAxisDistance(startVec,endVec):
			dist = (startVec - endVec).length
			if startVec.x > endVec.x:   
				distX = (startVec - endVec).x
			else:
				distX = (endVec - startVec).x
			if startVec.y > endVec.y:
				distY = (startVec - endVec).y
			else:
				distY = (endVec - startVec).y
			if startVec.z > endVec.z:
				distZ = (startVec - endVec).z
			else:
				distZ = (endVec - startVec).z
			return dist,distX,distY,distZ
#--------------------------------------------------------------
def get_component_distance():
	# print("get_component_distance")
	ComponentCoordsList = []
	selection_mode = check_selection_mode()
	startVec = 0
	endVec = 0
	dist = 0
	if bpy.context.editable_objects:
		objs = bpy.context.editable_objects
	else:
		objs = bpy.context.selected_objects

	if cPersistant.locked and cPersistant.dataType == "(Objects)":
		cPersistant.object_pointer_a = ""
		cPersistant.object_pointer_b = ""
		cPersistant.locked = False

	if not cPersistant.locked:
		cPersistant.component_index_a = None
		cPersistant.component_index_b = None
		cPersistant.object_pointer_a = ""
		cPersistant.object_pointer_b = ""
		totalElementsSelected = 0
		for obj in objs:
			if obj.mode != 'EDIT':  
				pass  
			else:
				QHDBM = bmesh.from_edit_mesh(obj.data)
				QHDBM.verts.ensure_lookup_table()
				selected_elements = []
				if selection_mode == '(Vertices)':
					selected_elements = [v for v in QHDBM.verts if v.select]
				elif selection_mode == '(Edges)':
					selected_elements = [e for e in QHDBM.edges if e.select]
				elif selection_mode == '(Faces)':
					selected_elements = [f for f in QHDBM.faces if f.select]
				totalElementsSelected += len(selected_elements)
				if totalElementsSelected > 2:
					cPersistant.dataType = selection_mode
					# QHDBM.free()
					break
				for element in selected_elements:
					if selection_mode == '(Vertices)':
						ComponentCoordsList.append(obj.matrix_world @ element.co)
					elif selection_mode == '(Edges)':
						edge_center = sum((obj.matrix_world @ v.co for v in element.verts), Vector()) / len(element.verts)
						ComponentCoordsList.append(edge_center)
					elif selection_mode == '(Faces)':
						ComponentCoordsList.append(obj.matrix_world @ element.calc_center_median())
					if not cPersistant.locked:
						if cPersistant.component_index_a == None:
							cPersistant.object_pointer_a = obj.name
							cPersistant.component_index_a = element.index
						elif cPersistant.component_index_b == None:
							cPersistant.object_pointer_b = obj.name
							if cPersistant.object_pointer_b == cPersistant.object_pointer_a:
								if element.index != cPersistant.component_index_a:
									cPersistant.component_index_b = element.index
							if cPersistant.object_pointer_b != cPersistant.object_pointer_a:
								cPersistant.component_index_b = element.index
					if len(ComponentCoordsList) >= 2:
						if not cPersistant.locked:
							cPersistant.dataType = selection_mode
						# QHDBM.free()
						break
				# QHDBM.free()
				if len(ComponentCoordsList) == 2:
					startVec = ComponentCoordsList[0]
					endVec = ComponentCoordsList[1]
					dist,distX,distY,distZ = getAxisDistance(startVec,endVec)
					return (startVec,endVec,dist,
							convert_distance_to_string(dist),
							convert_distance_to_string(distX),
							convert_distance_to_string(distY),
							convert_distance_to_string(distZ), selection_mode)
	elif cPersistant.locked:
		obj_A = bpy.data.objects.get(cPersistant.object_pointer_a)
		obj_B = bpy.data.objects.get(cPersistant.object_pointer_b)
		if obj_A == None or obj_B == None:
			cPersistant.object_pointer_a = ""
			cPersistant.object_pointer_b = ""
			cPersistant.locked = False
			return startVec,endVec,dist,"ObjLocked",""
		else:
			if obj_A != None:
				QHDBM = bmesh.from_edit_mesh(obj_A.data)
				QHDBM.verts.ensure_lookup_table()
				if cPersistant.dataType == '(Vertices)':
					ComponentCoordsList.append(obj_A.matrix_world @ QHDBM.verts[cPersistant.component_index_a].co)
				elif cPersistant.dataType == '(Edges)':
					edge_center =   (sum((obj_A.matrix_world @ v.co for v in QHDBM.edges[cPersistant.component_index_a].verts),
									Vector()) / len(QHDBM.edges[cPersistant.component_index_a].verts))
					ComponentCoordsList.append(edge_center)
				elif cPersistant.dataType == '(Faces)':
					ComponentCoordsList.append(obj_A.matrix_world @ QHDBM.faces[cPersistant.component_index_a].calc_center_median())
				# QHDBM.free()

			if obj_B != None:

				QHDBM = bmesh.from_edit_mesh(obj_B.data)
				QHDBM.verts.ensure_lookup_table()
				if cPersistant.dataType == '(Vertices)':
					ComponentCoordsList.append(obj_B.matrix_world @ QHDBM.verts[cPersistant.component_index_b].co)
				elif cPersistant.dataType == '(Edges)':
					edge_center =   (sum((obj_B.matrix_world @ v.co for v in QHDBM.edges[cPersistant.component_index_b].verts),
									Vector()) / len(QHDBM.edges[cPersistant.component_index_b].verts))
					ComponentCoordsList.append(edge_center)
				elif cPersistant.dataType == '(Faces)':
					ComponentCoordsList.append(obj_B.matrix_world @ QHDBM.faces[cPersistant.component_index_b].calc_center_median())
				# QHDBM.free()
				
			startVec = ComponentCoordsList[0]
			endVec = ComponentCoordsList[1]
			dist,distX,distY,distZ = getAxisDistance(startVec,endVec)
			return (startVec,endVec,dist,
					convert_distance_to_string(dist),
					convert_distance_to_string(distX),
					convert_distance_to_string(distY),
					convert_distance_to_string(distZ), cPersistant.dataType)
	return startVec,endVec,dist,"","","","",""



# ================================================================================================
# ================================================================================================
# ================================================================================================

#--------------------------------------------------------------
def draw_notifier(*args):
    QOLHUD_Distance_DrawingClass.handle_add()
#--------------------------------------------------------------
@persistent
def subscribe_to_obj(dummy=None):
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.LayerObjects, "active"), 
        owner=QOLHUD_Distance_DrawingClass,
        args=(),
        notify=draw_notifier,
        )
bpy.app.handlers.load_post.append(subscribe_to_obj)        
#--------------------------------------------------------------
def unsubscribe_to_obj(dummy=None):
    bpy.msgbus.clear_by_owner(QOLHUD_Distance_DrawingClass)
# --------------------------------------------------------------

def register():
    global distIcons_dict
    distIcons_dict = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    distIcons_dict.load("distanceAxis", os.path.join(icons_dir, "distanceAxis.png"), 'IMAGE')
    distIcons_dict.load("distanceLine", os.path.join(icons_dir, "distanceLine.png"), 'IMAGE')
    distIcons_dict.load("distanceMeasure", os.path.join(icons_dir, "distanceMeasure.png"), 'IMAGE')
    bpy.utils.register_class(QOLHUD_Distance_NPanel)
    bpy.utils.register_class(QOL_OT_SelectionLock)
    bpy.utils.register_class(QOL_OT_Distance_AxisToggler)
    bpy.utils.register_class(QOLHUD_Distance_Preferences)
    bpy.types.VIEW3D_HT_header.append(topbarIcon)
    subscribe_to_obj()
def unregister():
    bpy.utils.unregister_class(QOLHUD_Distance_NPanel)
    bpy.utils.unregister_class(QOL_OT_SelectionLock)
    bpy.utils.unregister_class(QOL_OT_Distance_AxisToggler)
    bpy.utils.unregister_class(QOLHUD_Distance_Preferences)
    unsubscribe_to_obj()
    bpy.types.VIEW3D_HT_header.remove(topbarIcon)
    global distIcons_dict
    bpy.utils.previews.remove(distIcons_dict)
if __name__ == "__main__":
    register()
